# polymarket-real-bot v0.1

A paper-first Polymarket trading bot foundation.

This is **not** a profit-guaranteeing bot. It is the machinery you need before real execution:
market discovery, strategy scoring, quote generation, risk checks, a paper ledger, structured logs,
and a deliberately blocked live executor.

## What this version does

- Fetches active Polymarket markets from Gamma.
- Filters for crypto / BTC / ETH style markets.
- Generates cautious paper quote intents.
- Applies exposure and order-size limits.
- Saves a persistent paper ledger to JSON.
- Refuses live trading until you intentionally implement the live executor.

## What this version does not do yet

- It does not place real orders.
- It does not sign EIP-712 orders.
- It does not derive Polymarket L2 API credentials.
- It does not run a true low-latency HFT loop.
- It does not guarantee profitable trades.

## Install

```bash
curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | sh
source "$HOME/.cargo/env"

cp config.example.toml config.toml
cp .env.example .env

cargo build --release
```

## Run paper mode

```bash
cargo run --release -- run --config config.toml --paper
```

## See paper ledger status

```bash
cargo run --release -- status --config config.toml
```

## Discover markets only

```bash
cargo run --release -- markets --config config.toml
```

## File layout

```text
src/
  main.rs       CLI entrypoint
  config.rs     TOML/env config
  gamma.rs      Gamma API client
  models.rs     Polymarket market parsing
  selector.rs   market filtering
  strategy.rs   quote-intent generation
  risk.rs       risk guardrails
  paper.rs      paper ledger and simulated orders
  live.rs       live executor stub that refuses to trade
```

## Recommended path

1. Run paper mode for several days.
2. Review `paper_ledger.jsonl` and `paper_state.json`.
3. Add a real order book client.
4. Add WebSocket market and user channels.
5. Add EIP-712 signing through the official Polymarket Rust SDK.
6. Only then enable live trading with small capital.

## Security notes

- Never commit `.env`.
- Never put private keys in code.
- Run with a separate wallet and limited funds.
- Start live mode with tiny limits only after successful paper tests.
