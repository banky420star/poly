use crate::{
    config::RiskConfig,
    paper::{PaperLedger, QuoteIntent},
};
use anyhow::{bail, Result};

pub struct RiskEngine {
    cfg: RiskConfig,
}

impl RiskEngine {
    pub fn new(cfg: RiskConfig) -> Self {
        Self { cfg }
    }

    pub fn check_quote(&self, quote: &QuoteIntent, ledger: &PaperLedger) -> Result<()> {
        if quote.size_usdc <= rust_decimal::Decimal::ZERO {
            bail!("quote size must be positive");
        }

        if quote.size_usdc > self.cfg.max_order_usdc {
            bail!(
                "quote size {} exceeds max_order_usdc {}",
                quote.size_usdc,
                self.cfg.max_order_usdc
            );
        }

        if ledger.open_intent_count() >= self.cfg.max_open_intents {
            bail!("too many open quote intents");
        }

        let projected_total = ledger.total_exposure_usdc() + quote.size_usdc;
        if projected_total > self.cfg.max_total_exposure_usdc {
            bail!(
                "projected total exposure {} exceeds max_total_exposure_usdc {}",
                projected_total,
                self.cfg.max_total_exposure_usdc
            );
        }

        let projected_market = ledger.market_exposure_usdc(&quote.market_id) + quote.size_usdc;
        if projected_market > self.cfg.max_market_exposure_usdc {
            bail!(
                "projected market exposure {} exceeds max_market_exposure_usdc {}",
                projected_market,
                self.cfg.max_market_exposure_usdc
            );
        }

        let projected_cash = ledger.cash_usdc - quote.size_usdc;
        if projected_cash < self.cfg.min_cash_buffer_usdc {
            bail!(
                "projected cash {} below min_cash_buffer_usdc {}",
                projected_cash,
                self.cfg.min_cash_buffer_usdc
            );
        }

        Ok(())
    }
}
