mod config;
mod gamma;
mod live;
mod models;
mod paper;
mod risk;
mod selector;
mod strategy;

use anyhow::{bail, Context, Result};
use clap::{Parser, Subcommand};
use config::AppConfig;
use gamma::GammaClient;
use paper::PaperLedger;
use risk::RiskEngine;
use selector::MarketSelector;
use std::time::Duration;
use strategy::InventoryAwareMaker;
use tracing::{error, info, warn};

#[derive(Parser, Debug)]
#[command(name = "polymarket-real-bot")]
#[command(about = "Paper-first Polymarket trading bot foundation")]
struct Cli {
    #[command(subcommand)]
    command: Commands,
}

#[derive(Subcommand, Debug)]
enum Commands {
    /// Run the bot loop. v0.1 supports paper mode only.
    Run {
        #[arg(short, long, default_value = "config.toml")]
        config: String,

        /// Force paper trading mode.
        #[arg(long, default_value_t = true)]
        paper: bool,

        /// Dangerous placeholder. v0.1 refuses this.
        #[arg(long, default_value_t = false)]
        live: bool,
    },

    /// Print currently selected markets.
    Markets {
        #[arg(short, long, default_value = "config.toml")]
        config: String,
    },

    /// Print paper ledger status.
    Status {
        #[arg(short, long, default_value = "config.toml")]
        config: String,
    },
}

#[tokio::main]
async fn main() -> Result<()> {
    dotenvy::dotenv().ok();

    tracing_subscriber::fmt()
        .with_env_filter(
            std::env::var("RUST_LOG")
                .unwrap_or_else(|_| "info,polymarket_real_bot=debug".to_string()),
        )
        .json()
        .init();

    let cli = Cli::parse();

    match cli.command {
        Commands::Run { config, paper, live } => run_bot(&config, paper, live).await,
        Commands::Markets { config } => show_markets(&config).await,
        Commands::Status { config } => show_status(&config),
    }
}

async fn run_bot(config_path: &str, paper: bool, live: bool) -> Result<()> {
    let cfg = AppConfig::from_file(config_path)
        .with_context(|| format!("failed to load config from {config_path}"))?;

    if live {
        live::refuse_live_trading()?;
    }

    if !paper {
        bail!("v0.1 only allows paper mode. Re-run with --paper.");
    }

    let gamma = GammaClient::new(cfg.gamma_base_url.clone())?;
    let selector = MarketSelector::new(cfg.market_filter.clone());
    let strategy = InventoryAwareMaker::new(cfg.strategy.clone());
    let risk = RiskEngine::new(cfg.risk.clone());
    let mut ledger = PaperLedger::load_or_new(&cfg.paper)?;

    let mut iteration: u64 = 0;

    loop {
        iteration += 1;
        info!(iteration, "starting loop");

        let markets = gamma.active_markets(cfg.market_filter.limit).await?;
        let selected = selector.select(&markets);

        info!(
            total_markets = markets.len(),
            selected_markets = selected.len(),
            "market discovery complete"
        );

        for market in selected {
            let quotes = strategy.build_quotes(market, &ledger)?;

            for quote in quotes {
                match risk.check_quote(&quote, &ledger) {
                    Ok(()) => {
                        let event = ledger.submit_quote_intent(&cfg.paper, quote)?;
                        info!(
                            market_id = event.market_id,
                            outcome = event.outcome,
                            side = event.side,
                            price = %event.price,
                            size_usdc = %event.size_usdc,
                            "paper quote accepted"
                        );
                    }
                    Err(e) => {
                        warn!(error = %e, "risk rejected quote");
                    }
                }
            }
        }

        ledger.save_state(&cfg.paper)?;

        if cfg.dry_run_iterations > 0 && iteration >= cfg.dry_run_iterations {
            info!("dry_run_iterations reached; exiting");
            break;
        }

        tokio::time::sleep(Duration::from_millis(cfg.loop_interval_ms)).await;
    }

    Ok(())
}

async fn show_markets(config_path: &str) -> Result<()> {
    let cfg = AppConfig::from_file(config_path)?;
    let gamma = GammaClient::new(cfg.gamma_base_url.clone())?;
    let selector = MarketSelector::new(cfg.market_filter.clone());

    let markets = gamma.active_markets(cfg.market_filter.limit).await?;
    let selected = selector.select(&markets);

    for market in selected {
        println!(
            "{} | {} | yes_mid={:?} | tokens={:?}",
            market.id,
            market.question,
            market.yes_mid(),
            market.clob_token_ids
        );
    }

    Ok(())
}

fn show_status(config_path: &str) -> Result<()> {
    let cfg = AppConfig::from_file(config_path)?;
    let ledger = PaperLedger::load_or_new(&cfg.paper)?;
    println!("{}", serde_json::to_string_pretty(&ledger)?);
    Ok(())
}
