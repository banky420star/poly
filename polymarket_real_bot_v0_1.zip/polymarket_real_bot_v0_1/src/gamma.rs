use crate::models::GammaMarket;
use anyhow::{Context, Result};
use reqwest::{Client, Url};

#[derive(Clone)]
pub struct GammaClient {
    base_url: Url,
    http: Client,
}

impl GammaClient {
    pub fn new(base_url: String) -> Result<Self> {
        Ok(Self {
            base_url: Url::parse(&base_url).context("invalid gamma_base_url")?,
            http: Client::builder().build()?,
        })
    }

    pub async fn active_markets(&self, limit: usize) -> Result<Vec<GammaMarket>> {
        let mut url = self.base_url.join("/markets")?;
        url.query_pairs_mut()
            .append_pair("active", "true")
            .append_pair("closed", "false")
            .append_pair("limit", &limit.to_string());

        let response = self
            .http
            .get(url)
            .send()
            .await?
            .error_for_status()
            .context("Gamma /markets request failed")?;

        let markets = response
            .json::<Vec<GammaMarket>>()
            .await
            .context("failed to decode Gamma /markets response")?;

        Ok(markets)
    }
}
