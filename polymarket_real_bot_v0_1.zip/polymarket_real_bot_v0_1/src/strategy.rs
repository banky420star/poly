use crate::{
    config::StrategyConfig,
    models::GammaMarket,
    paper::{PaperLedger, QuoteIntent},
};
use anyhow::Result;
use rust_decimal::prelude::ToPrimitive;
use rust_decimal::Decimal;
use rust_decimal_macros::dec;

pub struct InventoryAwareMaker {
    cfg: StrategyConfig,
}

impl InventoryAwareMaker {
    pub fn new(cfg: StrategyConfig) -> Self {
        Self { cfg }
    }

    pub fn build_quotes(&self, market: &GammaMarket, ledger: &PaperLedger) -> Result<Vec<QuoteIntent>> {
        let mut quotes = Vec::new();

        let Some(yes_mid) = market.yes_mid() else {
            return Ok(quotes);
        };

        if yes_mid < self.cfg.min_yes_mid || yes_mid > self.cfg.max_yes_mid {
            return Ok(quotes);
        }

        let no_mid = market.no_mid().unwrap_or(Decimal::ONE - yes_mid);

        let half_spread = bps_to_decimal(self.cfg.quote_spread_bps) / dec!(2);
        let maker_edge = bps_to_decimal(self.cfg.maker_edge_bps);

        if self.cfg.allow_buy_yes {
            if let Some(token_id) = market.yes_token_id() {
                let price = clamp_probability(yes_mid - half_spread - maker_edge);
                if price > dec!(0.01) {
                    quotes.push(QuoteIntent::buy(
                        market.id.clone(),
                        market.condition_or_id(),
                        token_id,
                        "YES".to_string(),
                        price,
                        ledger.default_order_size_usdc(),
                        format!("{} quote below yes_mid={}", self.cfg.name, yes_mid),
                    ));
                }
            }
        }

        if self.cfg.allow_buy_no {
            if let Some(token_id) = market.no_token_id() {
                let price = clamp_probability(no_mid - half_spread - maker_edge);
                if price > dec!(0.01) {
                    quotes.push(QuoteIntent::buy(
                        market.id.clone(),
                        market.condition_or_id(),
                        token_id,
                        "NO".to_string(),
                        price,
                        ledger.default_order_size_usdc(),
                        format!("{} quote below no_mid={}", self.cfg.name, no_mid),
                    ));
                }
            }
        }

        Ok(quotes)
    }
}

fn bps_to_decimal(bps: i64) -> Decimal {
    let raw = Decimal::from_i64(bps).unwrap_or(dec!(0));
    raw / dec!(10000)
}

fn clamp_probability(p: Decimal) -> Decimal {
    if p < dec!(0.01) {
        dec!(0.01)
    } else if p > dec!(0.99) {
        dec!(0.99)
    } else {
        p.round_dp(4)
    }
}
