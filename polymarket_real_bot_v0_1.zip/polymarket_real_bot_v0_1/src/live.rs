use anyhow::{bail, Result};

pub fn refuse_live_trading() -> Result<()> {
    bail!(
        "live trading is intentionally disabled in v0.1. Implement Polymarket SDK order signing, user-channel reconciliation, cancel-on-disconnect, and hard risk limits before enabling."
    )
}
